/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package stock_loc_dtc;

import java.io.*;
import java.util.ArrayList;
import org.json.JSONException;

/**
 *
 * @author dcosta
 */
public class EXP_CSV implements Runnable{
    
    final String url_header        = "https://apex.oracle.com/pls/apex/ora_dtc/hr/header/";
    final String url_loc           = "https://apex.oracle.com/pls/apex/ora_dtc/hr/loc/";
    final String url_line          = "https://apex.oracle.com/pls/apex/ora_dtc/hr/item_loc_hist/";
    
    final String out_file_path     = "C:\\Users\\dcosta\\Documents\\oracle\\output\\";
    final String fich              = "FICH_STOCK_LOC_";
    final String ext               = ".csv";
    
    final int    N_REC_THREADS         = 25;
    
    private String header = "";
    
        
    private ArrayList<String> inp_header;
    private ArrayList<String> inp_list_Locs;  
    private ArrayList<String> inp_list_ItemDoc;
    
    public EXP_CSV()
    {
    }    
       
    private void writeFile(String p_file_path
                          ,String p_header
                          ,ArrayList<String> p_list_ItemDoc
                         ) 
    {
        try {
            FileWriter fileWriter = new FileWriter(p_file_path);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            bufferedWriter.write(p_header);
            bufferedWriter.newLine();
            
            for (String str_line : p_list_ItemDoc)
            {
                String l_str=str_line;
                bufferedWriter.write(l_str);
                bufferedWriter.newLine();
            }
            // Close the BufferedWriter
            bufferedWriter.close();

            System.out.println("CSV File "+p_file_path+" created successfully on "+out_file_path+".");

        } catch (IOException e) {
            System.out.println("Error occurred while writing to the CSV file.");
        }
    }
    
     private void writeFileByLoc(String p_path
                                ,String p_loc
                                ,String p_header
                                ,ArrayList<String> p_list_ItemDoc
                                ) throws IOException
    {
        ArrayList<String> inp_list_ItemDoc_Loc=new ArrayList<String>();
        int cont=0;
            
        for (String str_line : p_list_ItemDoc)
        {
            String loc_str=str_line.substring(str_line.indexOf(";")+1);
            String cmp_loc=loc_str.substring(0,loc_str.indexOf(";"));
                
            if(cmp_loc.equals(p_loc))
            {
                inp_list_ItemDoc_Loc.add(str_line);
                cont++;
            }               

        }
             
        if(cont==0)
            System.out.println("LOC "+p_loc+" not found.");
        else
            this.writeFile(p_path
                          ,p_header
                          ,inp_list_ItemDoc_Loc
                          );

    }
    
    public void fillLists()
    {
       try{ 
            INP_JSON ijson_obj=new INP_JSON();
  
            ijson_obj.setHeader(url_header);
            inp_header=ijson_obj.getHeader();
        
            ijson_obj.fillList(url_line);
            inp_list_ItemDoc=ijson_obj.getList();
        
            ijson_obj.fillLocs(url_loc);
            inp_list_Locs=ijson_obj.getListLocs();
       }
       catch(IOException e)
       {
           System.out.println("Error occurred while writing to the CSV file: fillLists");
       }
       catch(JSONException e)
       {
           System.out.println("Error getting JSON for file");         
       }
       catch(Exception e)
       {
           System.out.println("Falhou praí:  fillLists");
       }
    }
    
    public synchronized void buildFile(String p_loc) throws IOException, JSONException, Exception 
    {
        for (String str_line : inp_header)
        {
            header=str_line;            
        }      
  

        /*this.writeFile(out_file_path+fich+ext
                        ,header
                        ,inp_list_ItemDoc
                        );*/
        this.writeFileByLoc(out_file_path+fich+p_loc+ext
                           ,p_loc
                           ,header
                           ,inp_list_ItemDoc
                           );
    }
    
    public void buildFiles() 
    {
        try {
              int cont=0;
              int res=0;

              for (String str_line : inp_list_Locs)
              {   
                //this.buildFile(str_line);
                
                cont++;                
                if(cont%N_REC_THREADS==0)
                {
                  res++;  
                  Thread tdtc=new Thread(this,Integer.toString(res));
                  tdtc.start();
                   while(tdtc.isAlive()) {
                        tdtc.sleep(1);
                   }     
                } 
              }      

        } catch (Exception e) {
            System.out.println("Falhou praí:  buildFiles");
        }
    }
    
    @Override  
    public void run() 
    {   
        String file_name=fich+Thread.currentThread().getName()+ext;
        int tloc=Integer.parseInt(Thread.currentThread().getName());
        int lim_sup=(N_REC_THREADS*tloc)+100;
        int lim_inf=((lim_sup-N_REC_THREADS)+1);        
          
        try{     
            System.out.println("Thread "+Integer.toString(tloc)+" processes files bwtween "+out_file_path+fich+lim_inf+ext+" and "+out_file_path+fich+lim_inf+ext+".");
            for(int i=lim_inf;i<=lim_sup;i++){
                this.buildFile(Integer.toString(i));
            }
            //this.buildFile(Thread.currentThread().getName());
        }
        catch(IOException e){
            System.out.println("Error occurred while writing to the CSV file "+file_name);
        }
        catch(JSONException e){
            System.out.println("Error getting JSON for file "+file_name);
        }
        catch (Exception e) {
            System.out.println("Falhou praí:  na Thread do ficheiro "+file_name);
        }
    }
 }
