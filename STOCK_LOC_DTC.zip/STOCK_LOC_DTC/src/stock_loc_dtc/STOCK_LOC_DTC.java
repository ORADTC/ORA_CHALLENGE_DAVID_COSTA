/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stock_loc_dtc;
/**
 *
 * @author dcosta
 */
public class STOCK_LOC_DTC {

    public static void main(String[] args) {
          EXP_CSV exp=new EXP_CSV();
          exp.fillLists();
          exp.buildFiles();
    }
    
}
