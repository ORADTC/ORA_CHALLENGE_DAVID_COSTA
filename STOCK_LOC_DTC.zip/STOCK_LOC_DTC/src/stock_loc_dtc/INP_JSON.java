package stock_loc_dtc;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.*;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dcosta
 */
public class INP_JSON {    
    
    public INP_JSON()
    {
    }
    
    
    private ITEM_LOC_SOH_HIST p_obj;
    
    private ArrayList<String> list_ItemDoc = new ArrayList<String>();
    private ArrayList<String> list_header  = new ArrayList<String>();
    private ArrayList<String> list_locs    = new ArrayList<String>();
    
    private static String readAll(Reader rd) throws Exception 
    {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
    
         return sb.toString();
    }
    
    public static JSONObject readJsonFromUrl(String url) throws Exception 
    {
        InputStream is = new URL(url).openStream();
        try {
               BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
               String jsonText = readAll(rd);
               JSONObject json = new JSONObject(jsonText);
               return json;
        } finally 
        {
            is.close();
         }
    }
    
    public void setHeader(String p_url) throws Exception 
    {
        JSONObject l_json = readJsonFromUrl(p_url);
        String inp=l_json.toString();
      
        JSONObject obj = new JSONObject(inp);

        JSONArray arr = obj.getJSONArray("items");
        for (int i = 0; i < arr.length(); i++) 
        {
            String l_header = arr.getJSONObject(i).getString("header");
            
            list_header.add(l_header);
        }
    }
    
     public void fillLocs(String p_url) throws Exception 
    {        
        JSONObject l_json = readJsonFromUrl(p_url);
        String inp=l_json.toString();
      
        JSONObject obj = new JSONObject(inp);

        JSONArray arr = obj.getJSONArray("items");
        for (int i = 0; i < arr.length(); i++) {
            String l_loc = Integer.toString(arr.getJSONObject(i).getInt("loc"));            
            list_locs.add(l_loc);
        }        
    }
    
    public void fillList(String p_url) throws Exception 
    {        
        JSONObject l_json = readJsonFromUrl(p_url);
        String inp=l_json.toString();
      
        JSONObject obj = new JSONObject(inp);

        JSONArray arr = obj.getJSONArray("items");
        for (int i = 0; i < arr.length(); i++) {
            String l_item               = arr.getJSONObject(i).getString("item");
            String l_loc                = Integer.toString(arr.getJSONObject(i).getInt("loc"));
            String l_dept               = Integer.toString(arr.getJSONObject(i).getInt("dept"));
            String l_unit_cost          = Double.toString(arr.getJSONObject(i).getDouble("unit_cost"));
            String l_stock_on_hand      = Integer.toString(arr.getJSONObject(i).getInt("stock_on_hand"));
            String l_stock_val          = Double.toString(arr.getJSONObject(i).getDouble("stock_val"));            
            
                
            p_obj=new ITEM_LOC_SOH_HIST(l_item
                                       ,l_loc
                                       ,l_dept
                                       ,l_unit_cost
                                       ,l_stock_on_hand
                                       ,l_stock_val); 
            
            list_ItemDoc.add(p_obj.getLine());
        }        
    }    
  
    public ArrayList<String> getHeader()
    {
        return list_header;
    }
    
    public ArrayList<String> getListLocs()
    {
        return list_locs;
    }
    
    public ArrayList<String> getList()
    {
        return list_ItemDoc;
    }
    
            
    
}
