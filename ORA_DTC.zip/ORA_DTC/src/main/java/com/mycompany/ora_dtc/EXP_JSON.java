/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.ora_dtc;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author dcosta
 */
public class EXP_JSON {
    
    public EXP_JSON()
    {
    }
    
    public void writeFileOnce(String p_file_path,String p_inp)
    {
        try {
            FileWriter fileWriter = new FileWriter(p_file_path);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            bufferedWriter.write(p_inp);

            // Close the BufferedWriter
            bufferedWriter.close();

            System.out.println("JSON file created successfully.");

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error occurred while writing to the CSV file.");
        }
    }
 }
