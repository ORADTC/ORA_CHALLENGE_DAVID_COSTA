/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ora_dtc;

/**
 *
 * @author dcosta
 */
public class ITEM_LOC_SOH_HIST {
    
    private String item;
    private String loc;
    private String dept;
    private String unit_cost;
    private String stock_on_hand;
    private String stock_val;
    
    public ITEM_LOC_SOH_HIST()
    {
    };
    
     public ITEM_LOC_SOH_HIST(String p_loc)
     {
         loc=p_loc;
         
         System.out.println("ITEM_LOC_SOH_HIST: "
                            +item);      
         
     };
    
     public ITEM_LOC_SOH_HIST(String p_item
                             ,String p_loc
                             ,String p_dept
                             ,String p_unit_cost
                             ,String p_stock_on_hand
                             ,String p_stock_val)
     {
         item=p_item;
         loc=p_loc;
         dept=p_dept; 
         unit_cost=p_unit_cost;
         stock_on_hand=p_stock_on_hand;
         stock_val=p_stock_val;
         
         System.out.println("ITEM_LOC_SOH_HIST: "
                            +item+" -- "
                            +loc+" -- "
                            +dept+" -- "
                            +unit_cost+" -- "
                            +stock_on_hand+" -- "
                            +stock_val);      
         
     };
     
     public void setItem(String p_item)
     {
         item=p_item;
     }
     
     public void setLoc(String p_loc)
     {
         loc=p_loc;
     }
     
     public void setDept(String p_dept)
     {
         dept=p_dept; 
     }
     
     public void setUnit_cost(String p_unit_cost){
         unit_cost=p_unit_cost;
     }
     
     public void setStock_on_hand(String p_stock_on_hand)
     {
         stock_on_hand=p_stock_on_hand;
     }
     
     public void setStock_val(String p_stock_val){
         stock_val=p_stock_val;
     }
     
     public String getItem()
     {
         return item;
     }
     
     public String getLoc()
     {
         return loc;
     }  
     
     public String getDept()
     {
         return dept;
     }
      
     public String getUnit_cost()
     {
         return unit_cost;
     }
       
     public String getStock_on_hand()
     {
         return stock_on_hand;
     }
       
     public String getStock_val()
     {
         return stock_val;
     }
     
     public String getLine()
     {
       String line=item+"," +loc+","+dept+","+unit_cost+"," +stock_on_hand+","+stock_val;
       
       return line;
     }
     
     public String getHeader()
     {
       String header="ITEM,LOC,DEPT,UNIT_COST,STOCK_ON_HAND,STOCK_VAL";       
       return header;
     } 
}
