package com.mycompany.ora_dtc;

import java.io.*;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;

import org.json.*;

import org.json.simple.JSONArray;
import org.json.simple.parser.*;

public class ORA_DTC /*implements Runnable*/{

    public ORA_DTC()
    {
        
    }
    
    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
    
         return sb.toString();
    }
    
    public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
    InputStream is = new URL(url).openStream();
    try {
      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
      String jsonText = readAll(rd);
      JSONObject json = new JSONObject(jsonText);
      return json;
    } finally {
      is.close();
    }
  }
    
    public static void main(String[] args) throws IOException, JSONException, Exception {
        
          
           JSONParser jsonParser = new JSONParser();
         
        try (FileReader reader = new FileReader("C:\\Users\\dcosta\\Documents\\oracle\\output\\inp.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
 
            JSONArray employeeList = (JSONArray) obj;
            System.out.println(employeeList);
             
            //Iterate over employee array
            //employeeList.forEach( emp -> parseEmployeeObject( (JSONObject) emp ) );
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        /*JSONObject json = readJsonFromUrl("https://apex.oracle.com/pls/apex/ora_dtc/hr/item_loc_dtc/110");
        String inp=json.toString();
        
        EXP_JSON exp=new EXP_JSON();
        exp.writeFileOnce("C:\\Users\\dcosta\\Documents\\oracle\\output\\fodase.json",inp);*/

        //System.out.println(json.toString());
        
        /*for (int i = 0; i < 3; i++) 
        {
          ORA_DTC ot=new ORA_DTC();
          Thread t = new Thread(ot);
          t.start();
        }*/
        /*ITEM_LOC_SOH_HIST itsh=new ITEM_LOC_SOH_HIST("660"
                                                    ,"110"
                                                    ,"87"
                                                    ,"16867.2045"
                                                    ,"5960"
                                                    ,"100528538.82");
        
        EXP_CSV exp=new EXP_CSV();
        exp.writeFile("C:\\Users\\dcosta\\Documents\\oracle\\output\\fich_cenas.csv",itsh);
    //}
    
    /*public void run()            
    {
      System.out.println(
                "Thread " + Thread.currentThread().getId()
                + " is running");
    }*/
    
    }
}
